#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
Default configurations.
'''

__author__ = 'Willam'

configs = {
	'db': {
		'host': '127.0.0.1'
	}
}